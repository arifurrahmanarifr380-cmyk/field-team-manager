import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import Dexie from 'dexie';
import { MapPin, ClipboardList, Search, FileText, Plus, Download, Printer, Trash2, LayoutDashboard, BookOpen, WifiOff } from 'lucide-react';
import './style.css';

const db = new Dexie('field-team-manager');
db.version(1).stores({
  visits: '++id, date, district, upazila, thana, area, institution, type, outcome, member',
  investigations: '++id, date, publisher, title, subject, status, area, visitId',
  settings: 'key'
});

const today = () => new Date().toISOString().slice(0,10);
const initialVisit = () => ({
  date: today(), member: '', district: 'চট্টগ্রাম', upazila: '', thana: '',
  area: '', institution: '', type: 'লাইব্রেরি', outcome: 'কোনো অনিয়ম পাওয়া যায়নি',
  observation: '', followup: '', suspectedBooks: ''
});

function makeReport(v) {
  const location = [v.district, v.upazila && `উপজেলা ${v.upazila}`, v.thana && `থানা ${v.thana}`, v.area].filter(Boolean).join(' জেলার ');
  const parts = [
    `তারিখ: ${v.date || 'উল্লেখ নেই'}`,
    `এলাকা: ${location || 'উল্লেখ নেই'}`,
    `প্রতিষ্ঠানের ধরন: ${v.type || 'উল্লেখ নেই'}`,
    `প্রতিষ্ঠান/স্থান: ${v.institution || 'উল্লেখ নেই'}`,
    v.member ? `পরিদর্শনকারী: ${v.member}` : '',
    `পরিদর্শনের ফলাফল: ${v.outcome || 'উল্লেখ নেই'}`,
    v.observation ? `পর্যবেক্ষণ: ${v.observation}` : '',
    v.suspectedBooks ? `সন্দেহজনক/নকল বই সংক্রান্ত তথ্য: ${v.suspectedBooks}` : '',
    v.followup ? `পরবর্তী করণীয়: ${v.followup}` : ''
  ].filter(Boolean);
  return `আসসালামু আলাইকুম স্যার।\n\n${parts.join('\n')}\n\nউপরোক্ত তথ্য সরেজমিনে পরিদর্শন/অনুসন্ধানের ভিত্তিতে লিপিবদ্ধ করা হলো।`;
}

function App() {
  const [page, setPage] = useState('dashboard');
  const [visits, setVisits] = useState([]);
  const [investigations, setInvestigations] = useState([]);
  const [form, setForm] = useState(initialVisit());
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [investigation, setInvestigation] = useState({date:today(),area:'',publisher:'',title:'',subject:'',edition:'',status:'সন্দেহজনক',details:'',evidenceNote:'',action:''});
  const online = typeof navigator !== 'undefined' ? navigator.onLine : true;

  async function refresh() {
    setVisits(await db.visits.orderBy('date').reverse().toArray());
    setInvestigations(await db.investigations.orderBy('date').reverse().toArray());
  }
  useEffect(() => { refresh(); }, []);

  const report = useMemo(() => makeReport(form), [form]);
  const filtered = visits.filter(v => [v.area,v.institution,v.thana,v.upazila,v.member,v.outcome].join(' ').toLowerCase().includes(query.toLowerCase()));

  const update = (key, value) => setForm(old => ({...old, [key]:value}));
  const updateInvestigation = (key, value) => setInvestigation(old => ({...old,[key]:value}));

  async function saveVisit(e) {
    e.preventDefault();
    await db.visits.add({...form, createdAt:new Date().toISOString()});
    setForm(initialVisit());
    await refresh();
    setNotice('ভিজিট রেকর্ড এই ডিভাইসে সংরক্ষিত হয়েছে।');
    setPage('visits');
  }
  async function saveInvestigation(e) {
    e.preventDefault();
    await db.investigations.add({...investigation, createdAt:new Date().toISOString()});
    setInvestigation({date:today(),area:'',publisher:'',title:'',subject:'',edition:'',status:'সন্দেহজনক',details:'',evidenceNote:'',action:''});
    await refresh();
    setNotice('অনুসন্ধান রেকর্ড এই ডিভাইসে সংরক্ষিত হয়েছে।');
  }
  async function deleteVisit(id) {
    if (confirm('এই ভিজিট রেকর্ড মুছে ফেলবেন?')) { await db.visits.delete(id); await refresh(); }
  }
  async function exportData() {
    const payload = {exportedAt:new Date().toISOString(), visits, investigations};
    const blob = new Blob([JSON.stringify(payload,null,2)], {type:'application/json'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `field-team-backup-${today()}.json`; a.click(); URL.revokeObjectURL(a.href);
  }
  function downloadReport() {
    const blob = new Blob([report], {type:'text/plain;charset=utf-8'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `visit-report-${form.date || today()}.txt`; a.click(); URL.revokeObjectURL(a.href);
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><MapPin size={22}/></div><div><b>ফিল্ড টিম</b><small>ম্যানেজমেন্ট সিস্টেম</small></div></div>
      <div className="nav-label">মূল মেনু</div>
      <button className={page==='dashboard'?'nav active':'nav'} onClick={()=>setPage('dashboard')}><LayoutDashboard size={18}/> ড্যাশবোর্ড</button>
      <button className={page==='new'?'nav active':'nav'} onClick={()=>setPage('new')}><Plus size={18}/> নতুন ভিজিট</button>
      <button className={page==='visits'?'nav active':'nav'} onClick={()=>setPage('visits')}><ClipboardList size={18}/> ভিজিট রেকর্ড</button>
      <button className={page==='investigations'?'nav active':'nav'} onClick={()=>setPage('investigations')}><Search size={18}/> নকল বই অনুসন্ধান</button>
      <button className={page==='report'?'nav active':'nav'} onClick={()=>setPage('report')}><FileText size={18}/> রিপোর্ট তৈরি</button>
      <div className="sidebar-bottom"><span className={online?'status-dot':'status-dot offline'}></span>{online?'অনলাইন':'অফলাইন মোড'}<small>ডেটা এই ডিভাইসে সংরক্ষিত</small></div>
    </aside>

    <main className="main">
      <header className="topbar"><div><div className="eyebrow">FIELD OPERATIONS</div><h1>{({dashboard:'ড্যাশবোর্ড',new:'নতুন ভিজিট রেকর্ড',visits:'ভিজিট রেকর্ড',investigations:'নকল বই অনুসন্ধান',report:'বাংলা রিপোর্ট তৈরি'})[page]}</h1></div><button className="outline-btn" onClick={exportData}><Download size={16}/> ব্যাকআপ</button></header>
      {notice && <div className="notice" onClick={()=>setNotice('')}>{notice} <span>×</span></div>}

      {page==='dashboard' && <><section className="welcome"><div><p className="welcome-kicker">আজকের কার্যক্রম</p><h2>কাজের সব তথ্য, এক জায়গায়।</h2><p>ভিজিট, অনুসন্ধান এবং দাপ্তরিক রিপোর্ট গুছিয়ে রাখুন।</p></div><div className="welcome-mark"><ClipboardList size={52}/></div></section>
        <section className="stats-grid">
          <Stat icon={<ClipboardList/>} label="মোট ভিজিট" value={visits.length} tone="blue"/>
          <Stat icon={<BookOpen/>} label="অনুসন্ধান রেকর্ড" value={investigations.length} tone="purple"/>
          <Stat icon={<MapPin/>} label="আজকের ভিজিট" value={visits.filter(v=>v.date===today()).length} tone="green"/>
          <Stat icon={<Search/>} label="সন্দেহজনক রেকর্ড" value={investigations.filter(i=>i.status==='সন্দেহজনক').length} tone="orange"/>
        </section>
        <section className="panel"><div className="panel-head"><div><h3>সাম্প্রতিক ভিজিট</h3><p>সর্বশেষ সংরক্ষিত রেকর্ড</p></div><button className="text-btn" onClick={()=>setPage('visits')}>সব দেখুন →</button></div>
          {visits.length===0?<Empty text="এখনও কোনো ভিজিট রেকর্ড নেই। প্রথম রেকর্ডটি যোগ করুন।"/>:<div className="table-wrap"><table><thead><tr><th>তারিখ</th><th>এলাকা</th><th>প্রতিষ্ঠান</th><th>ফলাফল</th></tr></thead><tbody>{visits.slice(0,5).map(v=><tr key={v.id}><td>{v.date}</td><td>{v.area||v.upazila||'—'}</td><td>{v.institution||v.type}</td><td><span className="pill">{v.outcome}</span></td></tr>)}</tbody></table></div>}
        </section>
        <section className="quick-actions"><button onClick={()=>setPage('new')}><Plus/> নতুন ভিজিট যোগ করুন</button><button onClick={()=>setPage('investigations')}><Search/> অনুসন্ধান নথিভুক্ত করুন</button><button onClick={()=>setPage('report')}><FileText/> রিপোর্ট তৈরি করুন</button></section>
      </>}

      {page==='new' && <div className="content-grid"><section className="panel form-panel"><div className="panel-head"><div><h3>ভিজিটের তথ্য</h3><p>প্রয়োজনীয় তথ্য পূরণ করে সংরক্ষণ করুন</p></div></div>
        <form onSubmit={saveVisit} className="form-grid">
          <Field label="তারিখ"><input type="date" value={form.date} onChange={e=>update('date',e.target.value)} required/></Field>
          <Field label="পরিদর্শনকারী"><input value={form.member} onChange={e=>update('member',e.target.value)} placeholder="সদস্যের নাম"/></Field>
          <Field label="জেলা"><input value={form.district} onChange={e=>update('district',e.target.value)} required/></Field>
          <Field label="উপজেলা"><input value={form.upazila} onChange={e=>update('upazila',e.target.value)} placeholder="উপজেলার নাম"/></Field>
          <Field label="থানা"><input value={form.thana} onChange={e=>update('thana',e.target.value)} placeholder="থানার নাম"/></Field>
          <Field label="বাজার / এলাকা"><input value={form.area} onChange={e=>update('area',e.target.value)} placeholder="এলাকার নাম" required/></Field>
          <Field label="প্রতিষ্ঠানের ধরন"><select value={form.type} onChange={e=>update('type',e.target.value)}>{['লাইব্রেরি','প্রেস','বাইন্ডিং','গোডাউন','পরিবহন/কুরিয়ার','অন্যান্য'].map(x=><option key={x}>{x}</option>)}</select></Field>
          <Field label="প্রতিষ্ঠানের নাম"><input value={form.institution} onChange={e=>update('institution',e.target.value)} placeholder="নাম লিখুন" required/></Field>
          <Field label="অনুসন্ধানের ফলাফল"><select value={form.outcome} onChange={e=>update('outcome',e.target.value)}>{['কোনো অনিয়ম পাওয়া যায়নি','সন্দেহজনক বই পাওয়া গেছে','নকল বই নিশ্চিত হয়েছে','আরও যাচাই প্রয়োজন','প্রযোজ্য নয়'].map(x=><option key={x}>{x}</option>)}</select></Field>
          <Field label="সন্দেহজনক বইয়ের সংক্ষিপ্ত তথ্য" wide><input value={form.suspectedBooks} onChange={e=>update('suspectedBooks',e.target.value)} placeholder="বই/প্রকাশক/বিষয়/সংস্করণ — প্রযোজ্য হলে"/></Field>
          <Field label="পর্যবেক্ষণ" wide><textarea rows="4" value={form.observation} onChange={e=>update('observation',e.target.value)} placeholder="যা যাচাই করেছেন এবং যা পেয়েছেন তা লিখুন"/></Field>
          <Field label="পরবর্তী করণীয়" wide><textarea rows="2" value={form.followup} onChange={e=>update('followup',e.target.value)} placeholder="প্রয়োজনে পরবর্তী পদক্ষেপ"/></Field>
          <div className="form-actions"><button className="primary-btn" type="submit">রেকর্ড সংরক্ষণ</button><button className="outline-btn" type="button" onClick={()=>setPage('report')}>রিপোর্টের প্রিভিউ</button></div>
        </form>
      </section><section className="panel report-preview"><h3><FileText size={18}/> লাইভ রিপোর্ট প্রিভিউ</h3><pre>{report}</pre><button className="outline-btn full" onClick={downloadReport}><Download size={16}/> TXT ডাউনলোড</button><button className="primary-btn full" onClick={()=>window.print()}><Printer size={16}/> প্রিন্ট / PDF</button></section></div>}

      {page==='visits' && <section className="panel"><div className="panel-head"><div><h3>সব ভিজিট</h3><p>{visits.length}টি রেকর্ড</p></div><div className="search-box"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="এলাকা বা প্রতিষ্ঠান খুঁজুন"/></div></div>
        {filtered.length===0?<Empty text="মিল পাওয়া যায়নি। নতুন ভিজিট যোগ করুন।"/>:<div className="table-wrap"><table><thead><tr><th>তারিখ</th><th>এলাকা</th><th>প্রতিষ্ঠান</th><th>ধরন</th><th>ফলাফল</th><th></th></tr></thead><tbody>{filtered.map(v=><tr key={v.id}><td>{v.date}</td><td>{[v.district,v.upazila,v.thana,v.area].filter(Boolean).join(' / ')}</td><td>{v.institution}</td><td>{v.type}</td><td><span className="pill">{v.outcome}</span></td><td><button className="icon-btn danger" title="মুছুন" onClick={()=>deleteVisit(v.id)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}
      </section>}

      {page==='investigations' && <div className="content-grid"><section className="panel form-panel"><div className="panel-head"><div><h3>নকল বই অনুসন্ধান</h3><p>সন্দেহ, যাচাই ও পদক্ষেপ নথিভুক্ত করুন</p></div></div>
        <form onSubmit={saveInvestigation} className="form-grid">
          <Field label="তারিখ"><input type="date" value={investigation.date} onChange={e=>updateInvestigation('date',e.target.value)} required/></Field>
          <Field label="এলাকা"><input value={investigation.area} onChange={e=>updateInvestigation('area',e.target.value)} required/></Field>
          <Field label="প্রকাশক / ছাপাখানা"><input value={investigation.publisher} onChange={e=>updateInvestigation('publisher',e.target.value)}/></Field>
          <Field label="বইয়ের নাম"><input value={investigation.title} onChange={e=>updateInvestigation('title',e.target.value)} required/></Field>
          <Field label="বিষয়"><input value={investigation.subject} onChange={e=>updateInvestigation('subject',e.target.value)}/></Field>
          <Field label="সংস্করণ / সাল"><input value={investigation.edition} onChange={e=>updateInvestigation('edition',e.target.value)}/></Field>
          <Field label="যাচাইয়ের অবস্থা"><select value={investigation.status} onChange={e=>updateInvestigation('status',e.target.value)}>{['সন্দেহজনক','যাচাই চলছে','নকল নিশ্চিত','নকল নয়','কর্তৃপক্ষের কাছে হস্তান্তর'].map(x=><option key={x}>{x}</option>)}</select></Field>
          <Field label="বিস্তারিত" wide><textarea rows="3" value={investigation.details} onChange={e=>updateInvestigation('details',e.target.value)} placeholder="কোন বৈশিষ্ট্যের কারণে সন্দেহ হয়েছে?"/></Field>
          <Field label="প্রমাণের নোট" wide><textarea rows="2" value={investigation.evidenceNote} onChange={e=>updateInvestigation('evidenceNote',e.target.value)} placeholder="ছবি/নমুনা/প্যাকেট নম্বরের বিবরণ; প্রমাণের আসল ফাইল আলাদাভাবে নিরাপদে রাখুন"/></Field>
          <Field label="গৃহীত পদক্ষেপ" wide><textarea rows="2" value={investigation.action} onChange={e=>updateInvestigation('action',e.target.value)} placeholder="যেমন: ঊর্ধ্বতন কর্তৃপক্ষকে জানানো"/></Field>
          <div className="form-actions"><button className="primary-btn" type="submit">অনুসন্ধান সংরক্ষণ</button></div>
        </form>
      </section><section className="panel"><h3>সাম্প্রতিক অনুসন্ধান</h3>{investigations.length===0?<Empty text="এখনও অনুসন্ধান নথিভুক্ত হয়নি।"/>:<div className="investigation-list">{investigations.map(i=><div className="investigation-item" key={i.id}><div className="investigation-top"><b>{i.title}</b><span className="pill">{i.status}</span></div><p>{i.area} · {i.publisher||'প্রকাশক উল্লেখ নেই'}</p><small>{i.date} {i.subject?`· ${i.subject}`:''}</small>{i.details&&<p>{i.details}</p>}</div>)}</div>}</section></div>}

      {page==='report' && <div className="content-grid"><section className="panel form-panel"><div className="panel-head"><div><h3>রিপোর্টের তথ্য</h3><p>ফিল্ডগুলো বদলালে রিপোর্ট স্বয়ংক্রিয়ভাবে আপডেট হবে</p></div></div><div className="form-grid">
        <Field label="তারিখ"><input type="date" value={form.date} onChange={e=>update('date',e.target.value)}/></Field>
        <Field label="পরিদর্শনকারী"><input value={form.member} onChange={e=>update('member',e.target.value)}/></Field>
        <Field label="জেলা"><input value={form.district} onChange={e=>update('district',e.target.value)}/></Field>
        <Field label="উপজেলা"><input value={form.upazila} onChange={e=>update('upazila',e.target.value)}/></Field>
        <Field label="থানা"><input value={form.thana} onChange={e=>update('thana',e.target.value)}/></Field>
        <Field label="বাজার / এলাকা"><input value={form.area} onChange={e=>update('area',e.target.value)}/></Field>
        <Field label="প্রতিষ্ঠানের ধরন"><select value={form.type} onChange={e=>update('type',e.target.value)}>{['লাইব্রেরি','প্রেস','বাইন্ডিং','গোডাউন','পরিবহন/কুরিয়ার','অন্যান্য'].map(x=><option key={x}>{x}</option>)}</select></Field>
        <Field label="প্রতিষ্ঠান"><input value={form.institution} onChange={e=>update('institution',e.target.value)}/></Field>
        <Field label="ফলাফল"><select value={form.outcome} onChange={e=>update('outcome',e.target.value)}>{['কোনো অনিয়ম পাওয়া যায়নি','সন্দেহজনক বই পাওয়া গেছে','নকল বই নিশ্চিত হয়েছে','আরও যাচাই প্রয়োজন','প্রযোজ্য নয়'].map(x=><option key={x}>{x}</option>)}</select></Field>
        <Field label="পর্যবেক্ষণ" wide><textarea rows="4" value={form.observation} onChange={e=>update('observation',e.target.value)}/></Field>
        <Field label="সন্দেহজনক বইয়ের তথ্য" wide><textarea rows="2" value={form.suspectedBooks} onChange={e=>update('suspectedBooks',e.target.value)}/></Field>
        <Field label="পরবর্তী করণীয়" wide><textarea rows="2" value={form.followup} onChange={e=>update('followup',e.target.value)}/></Field>
      </div></section><section className="panel report-preview printable"><div className="panel-head"><h3><FileText size={18}/> রিপোর্ট প্রিভিউ</h3><button className="outline-btn no-print" onClick={downloadReport}><Download size={16}/> TXT</button></div><pre>{report}</pre><button className="primary-btn full no-print" onClick={()=>window.print()}><Printer size={16}/> PDF হিসেবে সংরক্ষণ / প্রিন্ট</button><p className="hint no-print">প্রিন্ট ডায়ালগে “Save as PDF” বেছে নিন।</p></section></div>}
      <footer>Field Team Manager <span>প্রাথমিক সংস্করণ · স্থানীয় ডেটা স্টোরেজ</span></footer>
    </main>
  </div>;
}

function Stat({icon,label,value,tone}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{value}</strong></div></div>; }
function Field({label,wide,children}) { return <label className={`field ${wide?'wide':''}`}><span>{label}</span>{children}</label>; }
function Empty({text}) { return <div className="empty-state"><ClipboardList size={28}/><p>{text}</p></div>; }

createRoot(document.getElementById('root')).render(<App/>);

\n// PWA service-worker registration
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    import('virtual:pwa-register').then(({ registerSW }) => {
      registerSW({ immediate: true });
    }).catch(() => {});
  });
}
