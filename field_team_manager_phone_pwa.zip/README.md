# Field Team Manager — ফোনে চালানোর PWA সংস্করণ

এই প্যাকেজটি আগের MVP-কে installable PWA বানানোর প্রাথমিক প্রস্তুতি যোগ করে। এটি এখনও Android APK নয়।

## সবচেয়ে সহজ ফোন-ভিত্তিক পদ্ধতি: GitHub + Vercel

1. ZIP ফাইলটি ফোনে ডাউনলোড করে Extract করুন।
2. GitHub-এ সাইন ইন করুন এবং একটি নতুন repository তৈরি করুন।
3. ফোনের ব্রাউজারে GitHub-এর repository page খুলে **Add file → Upload files** ব্যবহার করে এই ফোল্ডারের ফাইলগুলো আপলোড করুন। ফোল্ডারের ভেতরের ফাইল/ফোল্ডারগুলো repository-র root-এ থাকবে; ZIP-টিকে একা আপলোড করলে deploy হবে না।
4. Vercel-এ সাইন ইন করে **Add New → Project** নির্বাচন করুন এবং GitHub repository import করুন।
5. Framework preset Vite/Other (Vite autodetect হলে সেটাই), Build command `npm run build`, Output directory `dist` রাখুন।
6. Deploy চাপুন। Build শেষ হলে Vercel একটি HTTPS URL দেবে।
7. Android ফোনের Chrome-এ সেই URL খুলুন। পেজ লোড হলে Chrome-এর ⋮ মেনুতে **Install app** বা **Add to Home screen** বেছে নিন।
8. Home Screen-এর নতুন আইকনে চাপ দিয়ে অ্যাপ চালু করুন।

## যদি শুধু ফোনে কাজ করেন
GitHub-এর মোবাইল ওয়েব UI কিছুটা অসুবিধাজনক হতে পারে। চাইলে Replit-এর মতো browser-based IDE ব্যবহার করে ZIP import করে build/deploy করা যায়; সেবা/ফ্রি-টিয়ার সময়ের সঙ্গে বদলাতে পারে। কোনো তৃতীয় পক্ষের সেবায় কোম্পানির সংবেদনশীল রিপোর্ট আপলোডের আগে প্রতিষ্ঠানের অনুমতি নিন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- PWA asset cache করে, কিন্তু সব API/route সম্পূর্ণ offline-ready—এমন নিশ্চয়তা নয়।
- IndexedDB-এর ডেটা একই browser/profile-এ থাকে; অন্য ফোনে নিজে থেকে sync হয় না।
- Browser storage clear করলে বা ফোন হারালে স্থানীয় রেকর্ড হারাতে পারে। নিয়মিত JSON backup নিন।
- প্রথমবার install ও assets cache করার জন্য ইন্টারনেট দরকার।
- এই প্রকল্পে Google Fonts-এর জন্য নেটওয়ার্ক লাগতে পারে; অফলাইনে fallback font থাকবে।
- Shared team sync, account identity, data permissions, cloud backup, APK packaging এবং end-to-end test এখনও বাকি।
- PWA install option সব browser/device-এ একভাবে নাও দেখা যেতে পারে; Chrome ও HTTPS ব্যবহার করুন।

## লোকাল ডেভেলপমেন্ট (কম্পিউটার থাকলে)
```bash
npm install
npm run dev
npm run build
npm run preview
```
